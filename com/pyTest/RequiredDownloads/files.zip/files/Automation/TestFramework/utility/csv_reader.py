import csv
import os


class CSVReader(object):
    """
    Utility class for reading CSV file
    """

    @staticmethod
    def Read_all(path):
        values = {}

        if os.path.exists(path):
            with open(path) as csv_file:
                reader = csv.DictReader(csv_file, delimiter=',', quotechar='"')
                for row in reader:
                    values[row['Name']] = row['Value']
        return values
