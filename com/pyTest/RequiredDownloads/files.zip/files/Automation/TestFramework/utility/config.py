import selenium.webdriver as webdriver
import os
import configparser


def get_Config(sectionName):
    config = configparser.RawConfigParser()
    configPath = os.path.abspath("./TestSuite/config.properties")
    config.read(configPath)
    return dict(config.items(sectionName))


browser_types = dict(chrome=webdriver.Chrome, firefox=webdriver.Firefox, ie=webdriver.Ie)
