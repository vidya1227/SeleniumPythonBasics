import logging
from traceback import print_stack
import configparser

from TestFramework.core.selenium_driver import SeleniumDriver


class BasePage(SeleniumDriver):
    """
    Base page for Web pages. All pages inherited from this class
    Contains all actions, navigations, getter of selenium interactions.
    """

    def __init__(self, driver):
        super(BasePage, self).__init__(driver)
        self.driver = driver
        self.timeout = 15

    def verifyPageTitle(self, titleToVerify):
        """
        Verify the page Title

        :param titleToVerify: Title on the page that needs to be verified
        """
        try:
            actualTitle = self.getTitle()
            # return self.utility.stringutil.verifyTextContains(actualTitle, titleToVerify)
        except:
            logging.error("Failed to get page title")
            print_stack()
            return False


