from selenium.webdriver.common.by import By
from traceback import print_stack
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import *
import logging
import time
import os
import allure


class SeleniumDriver():

    def __init__(self, driver):
        self.driver = driver

    def getTitle(self):
        return self.driver.title

    def getElement(self, locatorType, locator):
        element = None
        try:
            byType = self.getByType(locatorType.lower())
            element = self.driver.find_element(byType, locator)
            logging.info("Element found with locator: " + locator +
                         " and locatorType: " + locatorType)
        except Exception as e:
            logging.error("Element not found with locator: " + locator +
                          " and locatorType: ", exc_info=True)
        return element

    def getElementFromRoot(self, rootelement, locatorType, locator):
        element = None
        try:
            byType = self.getByType(locatorType.lower())
            element = rootelement.find_element(byType, locator)
            logging.info("Element found under root  with locator: " + locator +
                         " and locatorType: " + locatorType)
        except Exception as e:
            logging.error("Element not found under root with locator: " + locator +
                          " and locatorType: ", exc_info=True)
        return element

    def sleep(self, sec, info=""):
        """
        Put the program to wait for the specified amount of time
        """
        if info is not None:
            logging.info("Wait :: " + str(sec) + " seconds for " + info)
            try:
                time.sleep(sec)
            except:
                print_stack()

    def elementClick(self, locatorType="id", locator="", element=None):
        """
        Either provide element or a combination of locator and locatorType
        """

        try:
            if locator:
                element = self.getElement(locatorType, locator)
            element.click()
            logging.info("clicked on element with locator: " + locator +
                         " locatorType: " + locatorType)
        except:
            logging.error("cannot click on the element with locator: " + locator +
                          " locatorType: " + locatorType)
            print_stack()

    def sendKeys(self, data, locatorType="id", locator="", element=None):
        """
        Send keys to an element
        Either provide element or a combination of locator and locatorType
        """
        try:
            if locator:
                element = self.getElement(locatorType, locator)
            element.send_keys(data)
            logging.info("send data on element with locator: " + locator +
                         " locatorType: " + locatorType)
        except Exception as ex:
            logging.error("cannot send data on the element with locator: " + locator +
                          " locatorType: " + locatorType)
            logging.error(str(ex))
            print_stack()

    def clearKeys(self, locatorType="id", locator="", element=None):
        """
        Clear keys of an element
        Either provide element or a combination of locator and locatorType
        """
        try:
            if locator:
                element = self.getElement(locatorType, locator)
            element.clear()
            logging.info("Clear data of element with locator: " + locator +
                         " locatorType: " + locatorType)
        except:
            logging.error("cannot clear data of the element with locator: " + locator +
                          " locatorType: " + locatorType)
            print_stack()

    def getText(self, locatorType="id", locator="", element=None, info=""):
        """
        Get 'Text' on an element
        Either provide element or a combination of locator and locatorType
        """
        try:
            if locator:
                logging.debug("In locator condition")
                element = self.getElement(locatorType, locator)
            logging.debug("Before finding text")
            text = element.text
            logging.debug("After finding element, size is: " + str(len(text)))
            if len(text) == 0:
                text = element.get_attribute("innerText")
            if len(text) != 0:
                logging.info("Getting text on element :: " + info)
                logging.info("The text is :: '" + text + "'")
                text = text.strip()
        except:
            logging.error("Failed to get text on element " + info)
            print_stack()
            text = None
        return text

    def waitForElement(self, locatorType='id', locator="", timeout=10, pollFrequency=0.5):
        element = None
        try:
            logging.info("Waiting for maximum :: " + str(timeout) + " :: seconds for element to be clickable")

            wait = WebDriverWait(self.driver, timeout, poll_frequency=pollFrequency,
                                 ignored_exceptions=[NoSuchElementException,
                                                     ElementNotVisibleException,
                                                     ElementNotSelectableException])
            ByType = self.getByType(locatorType)
            element = wait.until(EC.element_to_be_clickable((ByType, locator)))

            logging.info("Element appeared on the web page")

        except:
            logging.info("Element not appeared on the web page")
            print_stack()

        return element

    def screenShot(self, resultMessage):
        """
        Take a screenshot of the current open web page
        """
        fileName = resultMessage + "." + str(round(time.time() * 1000)) + ".png"
        if len(fileName) >= 200:
            fileName = str(round(time.time() * 1000)) + ".png"
        screenshotDirectory = "../screenshots/"
        relativeFileName = screenshotDirectory + fileName
        currentDirectory = os.path.dirname(__file__)
        destinationFile = os.path.join(currentDirectory, relativeFileName)
        destinationDirectory = os.path.join(currentDirectory, screenshotDirectory)

        try:
            if not os.path.exists(destinationDirectory):
                os.makedirs(destinationDirectory)
            self.driver.save_screenshot(destinationFile)
            allure.attach(self.driver.get_screenshot_as_png(),
                          name=fileName,
                          attachment_type=allure.attachment_type.PNG)
            logging.info("Screenshot save to directory: " + destinationFile)
        except:
            logging.error("### Exception Occurred when taking screenshot")
            print_stack()

    def getByType(self, locatorType):
        locatorType = locatorType.lower()
        if locatorType == "id":
            return By.ID
        elif locatorType == "name":
            return By.NAME
        elif locatorType == "xpath":
            return By.XPATH
        elif locatorType == "css":
            return By.CSS_SELECTOR
        elif locatorType == "class":
            return By.CLASS_NAME
        elif locatorType == "link":
            return By.LINK_TEXT
        else:
            logging.info("Locator type" + locatorType + "not correct/supported")
        return False

    def isElementSelected(self, locatorType='id', locator=""):
        isSelected = None
        try:
            element = self.getElement(locatorType, locator)
            isSelected = element.is_selected()
            logging.info("Element found with locator: " + locator +
                         " and locatorType: " + locatorType)
        except:
            logging.error("Element not found with locator: " + locator +
                          " and locatorType: " + locatorType)

        return isSelected

    def getElementList(self, locatorType='id', locator=""):
        """
        Get list of elements
        """
        element = None
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            element = self.driver.find_elements(byType, locator)
            logging.info("Element list found with locator: " + locator +
                         " and locatorType: " + locatorType)
        except:
            logging.error("Element list not found with locator: " + locator +
                          " and locatorType: " + locatorType)

        return element

    def elementHover(self, locatorType='id', locator="", element=None):
        """
        Either provide element or a combination of locator and locatorType
        """

        try:
            if locator:
                element = self.getElement(locatorType, locator)
            hover = ActionChains(self.driver).move_to_element(element)
            hover.perform()
            time.sleep(2)
            logging.info("hover to element with locator: " + locator +
                         " locatorType: " + locatorType)
        except:
            logging.error("cannot hover to the element with locator: " + locator +
                          " locatorType: " + locatorType)
            print_stack()

    def isElementPresent(self, locatorType='id', locator="", element=None):
        """
        Check if element is present
        Either provide element or a combination of locator and locatorType
        """
        try:
            if locator:
                element = self.getElement(locatorType, locator)
            if element is not None:
                logging.info("Element found with locator: " + locator +
                             " and locatorType: " + locatorType)
                return True
            else:
                logging.error("Element not found with locator: " + locator +
                              " and locatorType: " + locatorType)
                return False
        except:
            logging.error("Element not found with locator: " + locator +
                          " and locatorType: " + locatorType)
            return False

    def isElementDisplayed(self, locatorType='id', locator=""):
        """
        Check if element is displayed
        Either provide element or a combination of locator and locatorType
        """
        isDisplayed = False
        try:
            element = self.getElement(locatorType, locator)
            if element is not None:
                isDisplayed = element.is_displayed()
                logging.info("Element is displayed with locator: " + locator +
                             " and locatorType: " + locatorType)
            else:
                logging.error("Element is not displayed with locator: " + locator +
                              " and locatorType: " + locatorType)
            return isDisplayed
        except:
            logging.error("Element is not displayed with locator: " + locator +
                          " and locatorType: " + locatorType)
            return False

    def isElementEnabled(self, locatorType='id', locator=""):
        """
        Check if element is Enabled
        Either provide element or a combination of locator and locatorType
        """
        try:
            element = self.getElement(locatorType, locator)
            return element.is_enabled()
        except:
            logging.error("Element is not Enabled with locator: " + locator +
                          " and locatorType: " + locatorType)
            return False

    def elementPresenceCheck(self, locatorType='id', locator=""):
        try:
            locatorType = locatorType.lower()
            byType = self.getByType(locatorType)
            elementList = self.driver.find_elements(byType, locator)
            if len(elementList) > 0:
                logging.info("Element Found")
                return True
            else:
                logging.info("Element not found")
                return False
        except:
            logging.info("Element not found")
            return False

    def webScroll(self, direction="up"):
        if direction == "up":
            # Scroll Up
            self.driver.execute_script("window.scrollBy(0, -1000);")
        if direction == "down":
            # Scroll Down
            self.driver.execute_script("window.scrollBy(0, 1000);")

    def getURL(self):
        '''
        Get the current URL
        :return: current URL
        '''
        currentURL = self.driver.current_url

        return currentURL

    def pageBack(self):
        '''
        page back the browser
        '''
        self.driver.execute_script("window.history.go(-1)")

    def getAttributeValue(self, locatorType='id', locator="", element=None, attribute=""):
        '''
        get attribute value
        '''
        try:
            if locator:
                logging.debug("In locator condition")
                element = self.getElement(locatorType, locator)
            attribute_value = element.get_attribute(attribute)
        except:
            logging.error("Failed to get " + attribute + " in element with locator: " +
                          locator + " and locatorType: " + locatorType)
            print_stack()
            attribute_value = None
        return attribute_value

    def refresh(self):
        self.driver.get(self.driver.current_url)

    def page_has_loaded(self):
        try:
            WebDriverWait(self.driver, 1000, poll_frequency=0.5).until(
                lambda driver: self.driver.execute_script('return document.readyState == "complete";'))
            WebDriverWait(self.driver, 1000, poll_frequency=0.5).until(
                lambda driver: self.driver.execute_script('return jQuery.active == 0'))
            WebDriverWait(self.driver, 1000, poll_frequency=0.5).until(
                lambda driver: self.driver.execute_script('return typeof jQuery != "undefined"'))
            WebDriverWait(self.driver, 1000, poll_frequency=0.5).until(lambda driver: self.driver.execute_script(
                'return angular.element(document).injector().get("$http").pendingRequests.length === 0'))
        except:
            return False

    def dropdownSelectElement(self, selector="", selectorType="value", locatorType='id', locator=""):
        try:
            element = self.getElement(locatorType, locator)
            sel = Select(element)
            if selectorType == "value":
                sel.select_by_value(selector)
                time.sleep(1)
            elif selectorType == "index":
                sel.select_by_index(selector)
                time.sleep(1)
            elif selectorType == "text":
                sel.select_by_visible_text(selector)
                time.sleep(1)
            logging.info("Element selected with selector: " + str(selector) +
                         " and selectorType: " + selectorType)

        except Exception as e:
            logging.error("Element not selected with selector: " + str(selector) +
                          " and selectorType: " + selectorType)
            logging.error(str(e))
            print_stack()

    def getDropdownOptionsCount(self, locatorType='id', locator=""):
        '''
        get the number of options of drop down list
        :return: number of Options of drop down list
        '''
        options = None
        try:
            element = self.getElement(locatorType, locator)
            sel = Select(element)
            options = sel.options
            logging.info("Element found with locator: " + locator +
                         " and locatorType: " + locatorType)
        except:
            logging.error("Element not found with locator: " + locator +
                          " and locatorType: " + locatorType)

        return options

    def getDropdownSelectedOptionText(self, locatorType='id', locator=""):
        '''
        get the text of selected option in drop down list
        :return: the text of selected option in drop down list
        '''
        selectedOption_text = None
        try:
            element = self.getElement(locatorType, locator)
            sel = Select(element)
            selectedOption_text = sel.first_selected_option.text
            logging.info("Return the selected option of drop down list with locator: " + locator +
                         " and locatorType: " + locatorType)
        except:
            logging.error("Can not return the selected option of drop down list with locator: " + locator +
                          " and locatorType: " + locatorType)

        return selectedOption_text

    def getDropdownSelectedOptionValue(self, locatorType='id', locator=""):
        '''
        get the value of selected option in drop down list
        :return: the value of selected option in drop down list
        '''
        selectedOption_value = None
        try:
            element = self.getElement(locatorType, locator)
            sel = Select(element)
            selectedOption_value = sel.first_selected_option.get_attribute("value")
            logging.info("Return the selected option of drop down list with locator: " + locator +
                         " and locatorType: " + locatorType)
        except:
            logging.error("Can not return the selected option of drop down list with locator: " + locator +
                          " and locatorType: " + locatorType)

        return selectedOption_value

    def GetTableHeaders(self, locatorType='id', locator=""):
        headers = ""
        headerscell = self.getElementList(locatorType, locator)
        for header in headerscell:
            headers = header.text

        if headers != "": headers = headers[1:]
        return headers

    def GetTableHeaderColumnNumber(self, headername, locatorType='id', locator=""):
        headers = -1
        found = False
        headerscell = self.getElementList(locatorType, locator)
        for header in headerscell:
            headers = headers + 1
            if headername == header.text:
                found = True
                break

        if found:
            headers = headers + 1  # tr or td starts from 1.
        else:
            headers = -1

        return headers

