from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging
from datetime import date, timedelta, datetime


class ExportJobs(BasePage):
    locator_dictionary = {
        "table": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']//table"),
        "tableheader": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table/thead/tr/th"),
        "totalfilescolumn": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr/td[5]"),
        "executiontimecolumn": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr/td[2]"),
        "pagefullbackward": (
        "xpath", "//a[contains(@class, 'ui-paginator-first ui-paginator-element ui-state-default ui-corner-all')]"),
        "pageprevoius": (
        "xpath", "//a[contains(@class, 'ui-paginator-prev ui-paginator-element ui-state-default ui-corner-all')]"),
        "pagefront": (
        "xpath", "//a[contains(@class, 'ui-paginator-next ui-paginator-element ui-state-default ui-corner-all')]"),
        "pagefullforward": (
        "xpath", "//a[contains(@class, 'ui-paginator-last ui-paginator-element ui-state-default ui-corner-all')]"),
    }
    cellxpath = "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr[rownum]/td[colnum]"
    rowxpath = "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr[rownum]/td"

    def CheckExportJobsloaded(self):
        self.sleep(1, "waiting for rule page to load")
        return self.waitForElement(*self.locator_dictionary['tableheader'])

    def GetExportJobTableHeaders(self):
        return self.GetTableHeaders(*self.locator_dictionary['tableheader'])

    def GetExportHeaderColumnNumber(self, headername):
        return self.GetTableHeaderColumnNumber(headername, *self.locator_dictionary['tableheader'])

    def GetCellData(self, rownum, colnum):
        # Get column header number
        locatortype = "xpath"
        locatorId = self.cellxpath.replace("rownum", rownum)
        locatorId = locatorId.replace("colnum", colnum)
        return self.getText(locatortype, locatorId)

    def GetRowNumberOfTotalFiles(self, total_files_count):
        rownum = -1
        found = False
        dt = date.today().strftime("%Y/%B/%d")
        colnum = self.GetExportHeaderColumnNumber("Execution Time")
        cells = self.getElementList(*self.locator_dictionary['rulecolumn'])
        for cell in cells:
            rownum = rownum + 1
            # get file count from the cells
            if cell.text.find(' / ' + total_files_count) != -1:
                # check execution time
                executiontime = self.GetCellData(rownum + 1, colnum)
                if executiontime == "--": continue
                executedatetime = executiontime.split(',')
                executedate = datetime.strptime(executedatetime[0], '%d-%b-%Y').strftime('%Y/%B/%d')
                if executedate == dt:
                    found = True
                    break

        if found:
            rownum = rownum + 1  # tr or td starts from 1.
        else:
            rownum = -1
        return rownum

    def GetLocationExportedData(self, rownum):
        colnum = self.GetExportHeaderColumnNumber("Location Exported")
        self.GetCellData(rownum, colnum)

    def GetStatusData(self, rownum):
        colnum = self.GetExportHeaderColumnNumber("Status")
        self.GetCellData(rownum, colnum)

    def ClickPagination(self, buttonName):
        if buttonName == 'Backward':
            self.elementClick(*self.locator_dictionary['pagefullbackward'])
        elif buttonName == 'BackPage':
            self.elementClick(*self.locator_dictionary['pageprevoius'])
        elif buttonName == 'NextPage':
            self.elementClick(*self.locator_dictionary['pagefront'])
        else:
            self.elementClick(*self.locator_dictionary['pagefullforward'])

    def GetPaginationEnabled(self, buttonName):
        if buttonName == 'Backward':
            value = self.getAttributeValue(*self.locator_dictionary['pagefullbackward'])
        elif buttonName == 'BackPage':
            value = self.getAttributeValue(*self.locator_dictionary['pageprevoius'])
        elif buttonName == 'NextPage':
            value = self.getAttributeValue(*self.locator_dictionary['pagefront'])
        else:
            value = self.getAttributeValue(*self.locator_dictionary['pagefullforward'])

        # verify the attribute
        if value.find("disabled"):
            return False
        else:
            return True

    def VerifyJobStatus(self, delay, rownum):
        self.sleep(delay)
        status = self.GetStatusData()

