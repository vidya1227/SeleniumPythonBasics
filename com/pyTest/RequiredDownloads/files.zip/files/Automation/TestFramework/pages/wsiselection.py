from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging


class WSISelection(BasePage):
    locator_dictionary = {
        "run_query": ("xpath", "//button[contains(text(),'Run Query')]"),
        "createnewrule": ("xpath", "//button[contains(text(),' Create new rule ')]"),
        "add_more": ("xpath", "//span[contains(text(),'Add filter')]"),
        "exportWSI": ("xpath", "//button[contains(text(),'Export WSIs')]"),
        "exportMetadata": ("xpath", "//button[contains(text(),'Export Metadata')]"),
        "OnlineWSICount": ("xpath", "//div[contains(@class,'content-container flex-row')]//div[1]//p[2]"),
        "OnlineCaseCount": ("xpath", "//div[contains(@class,'content-container flex-row')]//div[1]//p[3]//span[2]"),
        "ArchiveWSICount": ("xpath", "//div[contains(@class,'content-container flex-row')]//dp-results[1]/div[2]/div[2]/p[2]"),
        "ArchiveCaseCount": ("xpath", "//div[contains(@class,'content-container flex-row')]//dp-results[1]/div[2]/div[2]/p[3]/span[2]"),
        "AddFilters": ("xpath", "//span[contains(text(),'Add Filters')]"),
        "dialog_export_job": ("xpath", "//div[@class='flex-column']"),
        "dialog_export_job_message": ("xpath", "//div[@class='flex-column']/p"),
        "dialog_export_job_OK": ("xpath", "//button[contains(text(),'OK')]"),
        "wsidropDown": ("xpath", ".//p-multiselect"),
        "wsivalue": ("xpath",".//p-multiselect//div[@class='ui-multiselect-label-container']/span"),
        "casedesriptiontext": ("xpath", "//input[@class='dp-textbox ng-untouched ng-pristine ng-valid']"),
        "ageMintext": ("xpath", "//input[@placeholder='Min Age']"),
        "ageMaxtext": ("xpath", "//input[@placeholder='Max Age']"),
        "FilterRemovebutton": ("xpath", ".//button[@class='dp-button dp-quite']"),
        "registrationdate": ("xpath", "//input[@placeholder='Registration Date']"),
        "registrationdatetext": ("xpath", "//label[text()='Registration Date']")
    }
    # checkAddfilterId = "//p-checkbox[@class='ng-untouched ng-pristine ng-valid' and @ng-reflect-label='value']"
    # uncheckAddfilterId = "//p-checkbox[@class='ng-valid ng-dirty ng-touched' and @ng-reflect-label='value']"
    # filterId = "//p-checkbox[@ng-reflect-label='value']"

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def checkWSISelectionpageloaded(self):
        return self.waitForElement(*self.locator_dictionary['add_more'])

    def clickExportWSIButton(self):
        return self.elementClick(*self.locator_dictionary['exportWSI'])

    def clickExportMetadataButton(self):
        return self.elementClick(*self.locator_dictionary['exportMetadata'])

    def AddFilters(self):
        # Click on add_more button
        self.elementClick(*self.locator_dictionary['add_more'])
        self.waitForElement(*self.locator_dictionary['AddFilters'])

    def verifyExportWSImessage(self, message):
        self.sleep(1.5, "waiting for the pop up")
        self.waitForElement(*self.locator_dictionary['dialog_export_job'])
        messagefrom = self.getText(*self.locator_dictionary['dialog_export_job_message'])
        logging.info("Export WSI dialog message " + messagefrom)
        if messagefrom == message:
            return True
        else:
            return False

    def ClickOKinExportWSIdialog(self):
        self.elementClick(*self.locator_dictionary['dialog_export_job_OK'])

    def ClickRegistrationDate(self):
        self.elementClick(*self.locator_dictionary['registrationdate'])

    def ClickRunQueryButton(self):
        self.elementClick(*self.locator_dictionary['run_query'])

    def ClickRegistrationDateText(self):
        self.elementClick(*self.locator_dictionary['registrationdatetext'])

    def ClickCreateNewRuleButton(self):
        self.elementClick(*self.locator_dictionary['createnewrule'])

    def GetOnlineWSICount(self):
        return self.getText(*self.locator_dictionary['OnlineWSICount'])

    def GetOnlineCasesCount(self):
        return self.getText(*self.locator_dictionary['OnlineCaseCount'])

    def GetArchiveWSICount(self):
        return self.getText(*self.locator_dictionary['ArchiveWSICount'])

    def GetArchiveCasesCount(self):
        return self.getText(*self.locator_dictionary['ArchiveCaseCount'])

    def WaitForRunQueryloaded(self):
        self.waitForElement(*self.locator_dictionary['exportWSI'])
        self.sleep(1, "waiting for the query")

    def GetCreateNewRuleEnabled(self):
        return self.isElementEnabled(*self.locator_dictionary['createnewrule'])

    def GetExportWSIEnabled(self):
        return self.isElementEnabled(*self.locator_dictionary['exportWSI'])

    # pass attributes as list of strings eg - ["CaseTag$Fever#Knee", "CaseDescription$Value"]
    def SelectWSIAttribute(self, attributelist):

        try:
            # find the label for the attribute selection
            for attr in attributelist:
                # split the strings with $
                splitstrgs = attr.split("$")
                # if CaseDescription then enter the text
                if splitstrgs[0]=="CaseDescription":
                    # enter the value of the case description
                    self.sendKeys(splitstrgs[1], *self.locator_dictionary['casedesriptiontext'])
                elif splitstrgs[0]=="Age":
                    # enter the value of the age
                    ageSplit = splitstrgs[1].split("#")
                    self.sendKeys(ageSplit[0], *self.locator_dictionary['ageMintext'])
                    self.sendKeys(ageSplit[1], *self.locator_dictionary['ageMaxtext'])
                else:
                    # find the element of the attribute
                    rootelement = self.getElement("xpath", ".//label[contains(text(),'" + splitstrgs[0] + "')]")
                    parentelement = self.getElementFromRoot(rootelement, "xpath", "..")
                    dropdownelement = self.getElementFromRoot(parentelement, *self.locator_dictionary['wsidropDown'])

                    # click on the element
                    dropdownelement.click()
                    filters = splitstrgs[1].split("#")
                    wait = WebDriverWait(self.driver, 10, poll_frequency=0.5,
                                         ignored_exceptions=[NoSuchElementException,
                                                             ElementNotVisibleException,
                                                             ElementNotSelectableException])
                    filterelements = wait.until(EC.visibility_of_all_elements_located(("xpath", "//li/span")))
                    for filter in filters:
                        # verify the filterlements
                        for filterelement in filterelements:
                            if filterelement.text == filter:
                                filterelement.click()
                                break

                    rootelement.click()
                    self.sleep(1, "waiting for menu to close")

        except:
            logging.error("Unable to select the filter attribute")
            print_stack()

    # pass attributes as list of strings eg - ["CaseTag","CaseDescription"]
    def VerifyWSIAttributeinCaseSelection(self, attributelist):
        notexistfilters = ""

        # find the label for the attribute selection
        for attr in attributelist:
            element = self.getElement("xpath", "//label[contains(text(),'" + attr + "')]")
            if element == None:
                notexistfilters = notexistfilters + "," + attr

        if notexistfilters != "":
            notexistfilters = notexistfilters[1:]

        logging.info(notexistfilters)
        return notexistfilters

    # pass attributes as list of strings eg - ["CaseTag$Fever#Knee", "CaseDescription$Value"]
    def VerifyMetadataAttributeOptions(self, attributelist):
        notexistfiltersOptions = ""

        # find the label for the attribute selection
        for attr in attributelist:
            # split the strings with $
            splitstrgs = attr.split("$")
            # if CaseDescription then enter the text
            if splitstrgs[0]=="CaseDescription":
                # verify case description text box exists
                caseelement = self.getElement(*self.locator_dictionary['casedesriptiontext'])
                if caseelement == None:
                    notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0]
            elif splitstrgs[0]=="Age":
                # enter the value of the age
                if self.getElement(*self.locator_dictionary['ageMintext']) == None:
                    notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0]
            else:
                # find the element of the attribute
                rootelement = self.getElement("xpath", ".//label[contains(text(),'" + splitstrgs[0] + "')]")
                parentelement = self.getElementFromRoot(rootelement, "xpath", "..")
                dropdownelement = self.getElementFromRoot(parentelement, *self.locator_dictionary['wsidropDown'])

                # click on the element
                dropdownelement.click()
                filters = splitstrgs[1].split("#")
                wait = WebDriverWait(self.driver, 10, poll_frequency=0.5,
                                     ignored_exceptions=[NoSuchElementException,
                                                         ElementNotVisibleException,
                                                         ElementNotSelectableException])
                filterelements = wait.until(EC.visibility_of_all_elements_located(("xpath", "//li/span")))
                for filter in filters:
                    found = False
                    # verify the filterlements
                    for filterelement in filterelements:
                        if filterelement.text == filter:
                            found = True
                            break
                    if found == False:
                        notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0] + " - " + filter

                rootelement.click()
                self.sleep(1, "waiting for menu to close")

        if notexistfiltersOptions != "":
            notexistfiltersOptions = notexistfiltersOptions[1:]

        logging.info(notexistfiltersOptions)
        return notexistfiltersOptions

    # pass attributes as list of strings eg - ["CaseTag,CaseDescription"]
    def RemoveFilterssInCaseSelection(self, attributelist):
        notexistfiltersOptions = ""
        filtersattributes = attributelist.split(",")

        # find the label for the attribute selection
        for attr in filtersattributes:
            # find the element of the attribute
            rootelement = self.getElement("xpath", ".//label[contains(text(),'" + attr + "')]")
            if rootelement == None:
                notexistfiltersOptions = notexistfiltersOptions + "," + attr
            else:
                parentelement = self.getElementFromRoot(rootelement, "xpath", "..")
                crosselement = self.getElementFromRoot(parentelement, *self.locator_dictionary['FilterRemovebutton'])
                crosselement.click()
                self.sleep(1, "waiting for menu to close")

        if notexistfiltersOptions != "":
            notexistfiltersOptions = notexistfiltersOptions[1:]

        logging.info(notexistfiltersOptions)
        return notexistfiltersOptions

        # pass attributes as list of strings eg - ["CaseTag$Fever#Knee", "CaseDescription$Value"]
    def VerifyMetadataAttributeValues(self, attributelist):
        notexistfiltersOptions = ""

        # find the label for the attribute selection
        for attr in attributelist:
            # split the strings with $
            splitstrgs = attr.split("$")
            # if CaseDescription then enter the text
            if splitstrgs[0] == "CaseDescription":
                # verify case description text box exists
                caseelement = self.getText(*self.locator_dictionary['casedesriptiontext'])
                if caseelement != splitstrgs[1]:
                    notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0]
            elif splitstrgs[0] == "Age":
                # enter the value of the age
                if self.getText(*self.locator_dictionary['ageMintext']) == splitstrgs[1]:
                    notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0]
            else:
                # find the element of the attribute
                rootelement = self.getElement("xpath", ".//label[contains(text(),'" + splitstrgs[0] + "')]")
                parentelement = self.getElementFromRoot(rootelement, "xpath", "..")
                dropdownelement = self.getElementFromRoot(parentelement, *self.locator_dictionary['wsivalue'])
                wsifiltervalue = dropdownelement.text
                values = splitstrgs[1].split("#")
                for value in values:
                    if wsifiltervalue.find(value) == -1:
                        notexistfiltersOptions = notexistfiltersOptions + "," + splitstrgs[0] + " - " + value

        if notexistfiltersOptions != "":
            notexistfiltersOptions = notexistfiltersOptions[1:]

        logging.info(notexistfiltersOptions)
        return notexistfiltersOptions
