from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging


class Rules(BasePage):
    locator_dictionary = {
        "createnewrule": ("xpath", "//button[text()='Create new rule']"),
        "table": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table"),
        "exportjobs": ("xpath", "//a[contains(text(),'Export Jobs')]"),
        "username": ("xpath", "//div[@class='user-details']"),
        "availablespacetext": ("xpath", "//span[@class='space']"),
        "availablespacevalue": ("xpath", "//span[@class='space-value']"),
        "rulesheader": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table/thead/tr/th"),
        "rulecolumn": ("xpath", "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr/td[1]"),
        "dialogdeleterule": ("xpath", "//div[@class='flex-column']"),
        "dialogdeleterulemessage": ("xpath", "//div[@class='flex-column']/p"),
        "dialogdeleteruleno": ("xpath", "//button[contains(text(),'No')]"),
        "dialogdeleteruleyes": ("xpath", "//button[contains(text(),'Yes')]"),
        "dialogcreateok": ("xpath", "//button[contains(text(),'OK')]")
    }
    cellxpath = "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr[rownum]/td[colnum]"
    rowxpath = "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr[rownum]/td"
    deleteXpath = "//div[@class='ui-table-wrapper ng-star-inserted']/table/tbody/tr[rownum]/td[8]/span"

    def CheckRulesListloaded(self):
        self.sleep(1, "waiting for rule page to load")
        return self.waitForElement(*self.locator_dictionary['createnewrule'])

    def GetRuleTableHeaders(self):
        return self.GetTableHeaders(*self.locator_dictionary['rulesheader'])

    def GetHeaderColumnNumber(self, headername):
        return self.GetTableHeaderColumnNumber(headername, *self.locator_dictionary['rulesheader'])

    def GetRuleRowNumber(self, rulename):
        rownum = -1
        found = False
        rows = self.getElementList(*self.locator_dictionary['rulecolumn'])
        for row in rows:
            rownum = rownum + 1
            if rulename == row.text:
                found = True
                break

        if found:
            rownum = rownum + 1  # tr or td starts from 1.
        else:
            rownum = -1

        return rownum

    def GetCellData(self, rulename, header):
        # Get column header number
        colnum = self.GetHeaderColumnNumber(header)
        rownum = self.GetRuleRowNumber(rulename)
        locatortype = "xpath"
        locatorId = self.cellxpath.replace("rownum", rownum)
        locatorId = locatorId.replace("colnum", colnum)
        return self.getText(locatortype, locatorId)

    def DeleteRule(self, rulename):
        # Get row number of rule name
        status = False
        rownum = self.GetRuleRowNumber(rulename)
        locatortype = "xpath"
        locatorId = self.deleteXpath.replace("rownum", str(rownum))
        self.elementClick(locatortype, locatorId)
        self.sleep(1, "waiting for delete rule pop up")
        self.waitForElement(*self.locator_dictionary['dialogdeleterule'])
        messagefrom = self.getText(*self.locator_dictionary['dialogdeleterulemessage'])
        logging.info("Delete Rule dialog message " + messagefrom)

        if messagefrom == "Are you sure, you want to delete the Rule ?":
            status = True

        return status

    def VerifyRulePopup(self, message):
        # Get row number of rule name
        status = False
        self.sleep(1, "waiting for create rule pop up")
        self.waitForElement(*self.locator_dictionary['dialogdeleterule'])
        messagefrom = self.getText(*self.locator_dictionary['dialogdeleterulemessage'])
        logging.info("Create Rule dialog message " + messagefrom)

        if messagefrom == message:
            status = True

        return status

    def ClickYesButtonInDeleteDialog(self):
        self.elementClick(*self.locator_dictionary['dialogdeleteruleyes'])
        self.sleep(1, "waiting for delete")

    def ClickCreateNewRuleButton(self):
        self.elementClick(*self.locator_dictionary['createnewrule'])
        self.sleep(1, "waiting for loading")

    def ClickOKButtonInDialog(self):
        self.elementClick(*self.locator_dictionary['dialogcreateok'])
        self.sleep(1, "waiting for delete to go")

    def ClickNoButtonInDeleteDialog(self):
        self.elementClick(*self.locator_dictionary['dialogdeleteruleno'])
        self.sleep(1, "waiting for delete to go")

    def VerifyRule(self, rulename):
        status = False
        rownum = self.GetRuleRowNumber(rulename)
        if rownum != -1:
            status = True

        return status

    def GetRuleDetails(self, rulename):
        ruledetails = ""
        rownum = self.GetRuleRowNumber(rulename)
        if rownum == -1:
            return ruledetails

        locatortype = "xpath"
        locatorId = self.rowxpath.replace("rownum", str(rownum))
        cells = self.getElementList(locatortype, locatorId)
        for cell in cells:
            ruledetails = ruledetails + "$" + cell.text

        if ruledetails != "":
            ruledetails = ruledetails[1:]
        return ruledetails
