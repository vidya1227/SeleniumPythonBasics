from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging

from TestFramework.pages.calendar import Calendar


class Createnewrule(BasePage):
    locator_dictionary = {
        "name": ("xpath", "//input[@placeholder='Rule name']"),
        "description": ("xpath", "//input[@placeholder='Rule description']"),
        "startdate": ("xpath", "//p-calendar[@placeholder='Rule start date']"),
        "enddate": ("xpath", "//p-calendar[@placeholder='Rule end date']"),
        "executiontime": ("xpath", "//p-calendar[@placeholder='Rule execution time']"),
        "frequency": ("xpath", "//input[@placeholder='Frequency in days']"),
        "saverule": ("xpath", "//button[contains(text(),'Save Rule')]"),
        "cancel": ("xpath", "//button[text()='Cancel']"),
        "add_more": ("xpath", "//span[contains(text(),'Add more')]"),
        "wsidropDown": ("xpath", ".//p-multiselect"),
        "casedesriptiontext": ("xpath", "//input[@class='dp-textbox ng-untouched ng-pristine ng-valid']"),
        "ageMintext": ("xpath", "//input[@placeholder='Min Age']"),
        "ageMaxtext": ("xpath", "//input[@placeholder='Max Age']"),
        "minutepicker": ("xpath", "//div[@class='ui-minute-picker']/span[2]"),
        "hourpicker": ("xpath", "//div[@class='ui-hour-picker']/span[2]"),
        "hourupclick": ("xpath", "//div[@class='ui-hour-picker']/a[1]"),
        "hourdownclick": ("xpath", "//div[@class='ui-hour-picker']/a[2]"),
        "minupclick": ("xpath", "//div[@class='ui-minute-picker']/a[1]"),
        "mindownclick": ("xpath", "//div[@class='ui-minute-picker']/a[2]")
    }

    # returning value of the time to verify the Rule creation time
    def ProvideRuleDetails(self, name, description, startdate, enddate, executiontime, frequency):
        self.waitForElement(*self.locator_dictionary['frequency'])
        self.sleep(2, "waiting for the page to load")
        self.sendKeys(name, *self.locator_dictionary['name'])
        self.sendKeys(description, *self.locator_dictionary['description'])
        self.elementClick(*self.locator_dictionary['startdate'])
        # select start date in calendar
        calendar = Calendar(self.driver)
        calendar.SelectDate(startdate)
        self.sleep(1, "waiting for start date to select")
        self.elementClick(*self.locator_dictionary['enddate'])
        # select start date in calendar
        calendar = Calendar(self.driver)
        calendar.SelectDate(enddate)
        self.sleep(1, "waiting for end date to select")
        timesplit = executiontime.split(":")
        timevalue = self.SelectTime(timesplit[0], timesplit[1])
        self.sendKeys(frequency, *self.locator_dictionary['frequency'])
        return timevalue

    def SelectTime(self, hours, minutes):
        self.elementClick(*self.locator_dictionary['executiontime'])
        # get hour picker value
        hourval = int(self.getText(*self.locator_dictionary['hourpicker'])) + int(hours)
        minval = int(self.getText(*self.locator_dictionary['minutepicker'])) + int(minutes)
        for i in range(0, int(hours), 1):
            self.elementClick(*self.locator_dictionary['hourupclick'])
            self.sleep(.5)

        if minutes != "":
            for i in range(0, int(minutes), 1):
                self.elementClick(*self.locator_dictionary['minupclick'])
                self.sleep(.5)

        return str(hourval) + ":" + str(minval)

        # if hours > hourval:
        #     clicks = hourval - hours
        #     for i in range(0, clicks, 1):
        #         self.elementClick(*self.locator_dictionary['hourupclick'])
        #         self.sleep(.5)
        # elif hours < hourval:
        #     clicks = hours - hourval
        #     for i in range(0, clicks, 1):
        #         self.elementClick(*self.locator_dictionary['hourdownclick'])
        #         self.sleep(.5)

        # # verify if the minute is not null
        # if minutes == "":
        #     minval = self.getText(*self.locator_dictionary['minutepicker'])
        #     if minutes > minval:
        #         clicks = minval - minutes
        #         for i in range(0, clicks, 1):
        #             self.elementClick(*self.locator_dictionary['minupclick'])
        #             self.sleep(.5)
        #     elif minutes < minval:
        #         clicks = minutes - minval
        #         for i in range(0, clicks, 1):
        #             self.elementClick(*self.locator_dictionary['mindownclick'])
        #             self.sleep(.5)

    def CheckCreateRulePageLoaded(self):
        self.sleep(1, "waiting for create new rule page to load")
        return self.waitForElement(*self.locator_dictionary['frequency'])

    def ClickSaveButton(self):
        self.elementClick(*self.locator_dictionary['saverule'])

    def ClickCancelButton(self):
        self.elementClick(*self.locator_dictionary['cancel'])

    def EnterRuleName(self, rule_name):
        self.sendKeys(rule_name, *self.locator_dictionary['name'])

    def EnterRuleDescription(self, description):
        self.sendKeys(description, *self.locator_dictionary['description'])

    def EnterStartDate(self, date):
        self.elementClick(*self.locator_dictionary['startdate'])
        # select start date in calendar
        calendar = Calendar(self.driver)
        calendar.SelectDate(date)
        self.sleep(1, "waiting for start date to select")

    def EnterEndDate(self, date):
        self.elementClick(*self.locator_dictionary['enddate'])
        # select start date in calendar
        calendar = Calendar(self.driver)
        calendar.SelectDate(date)
        self.sleep(1, "waiting for end date to select")

    def EnterExecutionTime(self, time):
        timesplit = time.split(":")
        self.SelectTime(timesplit[0], timesplit[1])

    def EnterFrequency(self, frequency):
        self.sendKeys(frequency, *self.locator_dictionary['frequency'])