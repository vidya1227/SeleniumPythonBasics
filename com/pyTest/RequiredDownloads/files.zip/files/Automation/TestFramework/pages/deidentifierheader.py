from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging

class DeidentifierHeader(BasePage):
    locator_dictionary = {
        "wsiselection": ("xpath", "//a[contains(text(),'WSI Selection')]"),
        "rules": ("xpath", "//a[contains(text(),'Rules')]"),
        "exportjobs": ("xpath", "//a[contains(text(),'Export Jobs')]"),
        "username": ("xpath", "//div[@class='user-details']"),
        "availablespacetext": ("xpath", "//span[@class='space']"),
        "availablespacevalue": ("xpath", "//span[@class='space-value']")
    }

    def ClickWSISelection(self):
        return self.elementClick(*self.locator_dictionary['wsiselection'])

    def ClickRules(self):
        return self.elementClick(*self.locator_dictionary['rules'])

    def ClickExportJobs(self):
        return self.elementClick(*self.locator_dictionary['exportjobs'])

    def LogoutDeid(self):
        self.elementClick(*self.locator_dictionary['username'])
        wait = WebDriverWait(self.driver, 10, poll_frequency=0.5,
                             ignored_exceptions=[NoSuchElementException,
                                                 ElementNotVisibleException,
                                                 ElementNotSelectableException])
        menuelements = wait.until(EC.visibility_of_all_elements_located(("xpath", "//li/a/span")))
        self.sleep(1, "waiting for menu")
        for menu in menuelements:
            if menu.text == "Logoff":
                menu.click()
                self.sleep(1, "waiting for log off")
                break

    def GetAvailableSpace(self):
        return self.getText(*self.locator_dictionary['availablespacevalue'])