from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging


class Calendar(BasePage):
    locator_dictionary = {
        "registrationdateclear": ("xpath", "//span[contains(text(),'Clear')]"),
        "registrationdatetoday": ("xpath", "//span[contains(text(),'Today')]"),
        "registrationdateyearcombo": ("xpath", "//select[contains(@class,'ui-datepicker-year')]"),
        "registrationdatemonthcombo": ("xpath", "//div[@class='ui-datepicker-title']/select[contains(@class,'ui-datepicker-month')]"),
        "registrationselectedtoday": ("xpath", "//td[contains(@class,'ui-datepicker-today')]/a")
    }
    registrationdatelink = "//a[text()='value']"
    dayId = "//span[contains(text(),'value')]"
    monthdict = {
        "January": 0,
        "February": 1,
        "March": 2,
        "April": 3,
        "May": 4,
        "June": 5,
        "July": 6,
        "August": 7,
        "September": 8,
        "October": 9,
        "November": 10,
        "December": 11
    }

    # provide date in the format - 2013/June/20 ,  2018/January/3
    def SelectRegistrationDate(self, startDate, endDate):
        # split startDate and endDate
        startdatestrings = startDate.split('/')
        enddatestrings = endDate.split('/')

        # select the startDate
        # self.dropdownSelectElement(startdatestrings[1], "value", *self.locator_dictionary['registrationdatemonthcombo'])
        self.dropdownSelectElement(self.monthdict[startdatestrings[1]], "index",
                                   *self.locator_dictionary['registrationdatemonthcombo'])
        self.sleep(1, "waiting for month selection")
        self.dropdownSelectElement(startdatestrings[0], "value", *self.locator_dictionary['registrationdateyearcombo'])
        self.sleep(1, "waiting for year selection")
        # click date link
        startreplace = self.registrationdatelink.replace("value", startdatestrings[2])
        self.elementClick("xpath", startreplace)
        self.sleep(1, "waiting for date selection")

        # select the endDate
        self.dropdownSelectElement(enddatestrings[0], "value", *self.locator_dictionary['registrationdateyearcombo'])
        self.sleep(1, "waiting for year selection")
        self.dropdownSelectElement(self.monthdict[enddatestrings[1]], "index",
                                   *self.locator_dictionary['registrationdatemonthcombo'])
        self.sleep(1, "waiting for month selection")
        # click date link
        endreplace = self.registrationdatelink.replace("value", enddatestrings[2])
        self.elementClick("xpath", endreplace)
        self.sleep(1, "waiting for date selection")


    def verifydaysstringinCalendar(self):
        strDaysnotfound = ""
        strDays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]
        for day in strDays:
            locatortype = "xpath"
            locatorId = self.dayId.replace("value", day)
            element = self.getElement(locatortype, locatorId)
            if (element == None):
                strDaysnotfound = strDaysnotfound + "," + day

        if strDaysnotfound != "":
            strDaysnotfound = strDaysnotfound[1:]

        return strDaysnotfound

    def checkRegistrationDateCalendarloaded(self):
        return self.waitForElement(*self.locator_dictionary['registrationdateclear'])

    def GetControlDisplayed(self, controlIdentifier):
        return self.isElementDisplayed(*self.locator_dictionary[controlIdentifier])

    def GetTodaysSelectedDate(self):
        return self.getText(*self.locator_dictionary['registrationselectedtoday'])

    def SelectDate(self, startDate):
        # split startDate and endDate
        startdatestrings = startDate.split('/')

        # select the startDate
        self.dropdownSelectElement(self.monthdict[startdatestrings[1]], "index",
                                   *self.locator_dictionary['registrationdatemonthcombo'])
        self.sleep(.5, "waiting for month selection")
        self.dropdownSelectElement(startdatestrings[0], "value", *self.locator_dictionary['registrationdateyearcombo'])
        self.sleep(.5, "waiting for year selection")
        # click date link
        dateText = startdatestrings[2]
        if (int(startdatestrings[2]) >= 1 and int(startdatestrings[2])) <= 9:
            if len(startdatestrings[2]) > 1:
                dateText = startdatestrings[2][1:]

        startreplace = self.registrationdatelink.replace("value", dateText)
        self.elementClick("xpath", startreplace)
        self.sleep(.5, "waiting for date selection")