from traceback import print_stack

from selenium.common.exceptions import *
from selenium.webdriver.support.wait import WebDriverWait

from TestFramework.core.basepage import BasePage
from selenium.webdriver.support import expected_conditions as EC
import logging


class AddFilters(BasePage):
    locator_dictionary = {
        "AddFilters": ("xpath", "//span[contains(text(),'Add Filters')]"),
        "Add": ("xpath", "//button[contains(text(),'Add')]"),
        "Cancel": ("xpath", "//button[contains(text(),'Cancel')]"),
        "AgeCheckBox": ("xpath", "//label[contains(text(),'Age')]"),
    }
    #checkAddfilterId = "//p-checkbox[@class='ng-untouched ng-pristine ng-valid' and @ng-reflect-label='value']"
    checkAddfilterId = "//p-checkbox[@class='ng-untouched ng-pristine ng-valid']/label[contains(text(),'value')]"
    #uncheckAddfilterId = "//p-checkbox[@class='ng-valid ng-dirty ng-touched' and @ng-reflect-label='value']"
    uncheckAddfilterId = "//p-checkbox[@class='ng-dirty ng-touched']/label[contains(text(),'value')]"
    filterId = "//p-checkbox[@name='filter']/label[contains(text(),'value')]"

    def checkAddFilterDialogloaded(self):
        self.sleep(1, "waiting for checkbox to load")
        return self.waitForElement(*self.locator_dictionary['AgeCheckBox'])

    def verifyWSIsFiltersinAddFilterDialog(self, Filters):
        notexistfilters = ""
        # get the list of filters
        for filter in Filters:
            # locator type and locator
            locatortype = "xpath"
            locatorId = self.filterId.replace("value", filter)
            element = self.getElement(locatortype, locatorId)
            if (element == None):
                notexistfilters = notexistfilters + "," + filter

        if notexistfilters != "":
            notexistfilters = notexistfilters[1:]

        logging.info(notexistfilters)
        return notexistfilters

    def checkWSIsFilters(self, Filters):
        # get the list of filters
        for filter in Filters:
            # locator type and locator
            locatortype = "xpath"
            locatorId = self.checkAddfilterId.replace("value", filter)
            element = self.getElement(locatortype, locatorId)
            if (element != None):
                element.click()

    def getWSIsFiltersstate(self, Filters):
        filterstates = ""
        # get the list of filters
        for filter in Filters:
            # locator type and locator
            locatortype = "xpath"
            locatorId = self.filterId.replace("value", filter)
            element = self.getElement(locatortype, locatorId)
            if element.get_attribute("class").find("ui-label-disabled") != -1:
                filterstates = filterstates + "," + filter + "$disabled"
            else:
                filterstates = filterstates + "," + filter + "$enabled"

        if filterstates != "":
            filterstates = filterstates[1:]

        logging.info(filterstates)
        return filterstates

    def uncheckWSIsFilters(self, Filters):
        # get the list of filters
        for filter in Filters:
            # locator type and locator
            locatortype = "xpath"
            locatorId = self.uncheckAddfilterId.replace("value", filter)
            element = self.getElement(locatortype, locatorId)
            if (element != None):
                element.click()

    def ClickCancelinAddFilterdialog(self):
        self.elementClick(*self.locator_dictionary['Cancel'])

    def ClickAddinAddFilterdialog(self):
        self.elementClick(*self.locator_dictionary['Add'])