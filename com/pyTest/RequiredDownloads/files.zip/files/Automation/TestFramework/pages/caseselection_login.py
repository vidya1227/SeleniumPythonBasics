from TestFramework.core.basepage import BasePage


class CaseSelection_Login(BasePage):
    locator_dictionary = {
        "username": ("xpath", "//input[@id='username']"),
        "password": ("xpath" , "//input[@id='password']"),
        "login_button": ("xpath", "//input[@value='Log in']")
    }

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def login(self, username, passwd):
        self.sendKeys(username, *self.locator_dictionary['username'])
        self.sendKeys(passwd, *self.locator_dictionary['password'])
        self.elementClick(*self.locator_dictionary['login_button'])

    def checkcaseselectionloginpageloaded(self):
        self.waitForElement(*self.locator_dictionary['username'])
        self.sleep(2, "wait till page loads")