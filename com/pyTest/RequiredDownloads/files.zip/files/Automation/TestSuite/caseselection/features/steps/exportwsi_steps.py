import csv
import os
import time
from _csv import reader

from behave import *

from TestFramework.pages.deidentifierheader import DeidentifierHeader
from TestFramework.pages.exportjobs import ExportJobs
from TestFramework.pages.rules import Rules
from TestFramework.pages.wsiselection import WSISelection
import logging
import TestFramework.utility.config as cf
import json

use_step_matcher("re")
ijobrow = 0
outputexportedpath = ""
queryfolderpath = ""
onlinewsicount = ""
onlinecasecount = ""
archivewsicount = ""
archivecasecount = ""


@step("A job should be created in the Export Job list in (?P<Wait>.+) seconds")
def step_impl(context, Wait):
    """
    :type context: behave.runner.Context
    """
    global ijobrow
    # get onlineWSICount
    wsipage = WSISelection(context.driver)
    onlinewsicount = wsipage.GetOnlineWSICount()

    page = DeidentifierHeader(context.driver)
    page.ClickExportJobs()

    exportpage = ExportJobs(context.driver)
    exportpage.CheckExportJobsloaded()
    ijobrow = exportpage.GetRowNumberOfTotalFiles(onlinewsicount)

    # wait till the job completes
    delayinbetweenverify = int(Wait) / 4
    jobstat = ""
    message = ""
    for i in range(0, 4, 1):
        status = exportpage.VerifyJobStatus(delayinbetweenverify, ijobrow)
        if status == "PARTIAL" or status == "FAILED":
            jobstat = "FAIL"
            logging.error("Exported job failed. status - " + status)
            message = "Exported job failed. status - " + status
            break
        elif status == "SUCCESSFUL":
            logging.info("Exported job success. status - " + status)
            message = "Exported job success. status - " + status
            jobstat = "PASS"
            break

        # Click on the Rules page and come back to export jobs page to refresh
        page.ClickRules()
        rulepage = Rules(context.driver)
        rulepage.CheckRulesListloaded()
        exportpage = ExportJobs(context.driver)
        exportpage.CheckExportJobsloaded()

    if jobstat != "":
        jobstat = "FAIL"
        logging.error("Exported job not completed upon waiting for " + str(Wait) + " seconds")
        message = "Exported job not completed upon waiting for " + str(Wait) + " seconds"

    assert jobstat == "PASS", message


@when("Exported job is successful")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    global outputexportedpath
    exportpage = ExportJobs(context.driver)
    exportpage.CheckExportJobsloaded()
    outputexportedpath = exportpage.GetLocationExportedData(ijobrow)


@then("Verify CSV and json created in the output transaction folder")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    # waiting for 5 seconds to folder create and folder sync
    time.sleep(5)
    filesstring = ""
    # verify Json files and CSV file created
    jsonfiles = [f for f in os.listdir(outputexportedpath) if f.endswith('.json')]
    csvfiles = [f for f in os.listdir(outputexportedpath) if f.endswith('.csv')]

    if len(jsonfiles) != 1:
        filesstring = filesstring + ", Json files count is not equal to 1. created count - " + str(len(jsonfiles))

    if len(csvfiles) != 1:
        filesstring = filesstring + ", csv files count is not equal to 1. created count - " + str(len(csvfiles))

    assert filesstring != "", filesstring[1:]


@step("Click on Export Metadata button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """

    wsipage = WSISelection(context.driver)
    wsipage.WaitForRunQueryloaded()
    wsipage.clickExportMetadataButton()


@then("Pop up to be shown as Export results has been initiated successfully\.")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    mess = page.verifyExportWSImessage("Export results has been initiated successfully.")
    page.ClickOKinExportWSIdialog()
    assert mess == True, "Message not matching - Export results has been initiated successfully."


@step("Verify CSV and json created in the Query folder")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    # waiting for 5 seconds to folder create and folder sync
    time.sleep(5)
    global queryfolderpath
    filesstring = ""
    # get the Query folder
    config_details = cf.get_Config("CaseSelectionUI")
    directory = config_details["outputdirectory"]
    queryfolderpath = max([os.path.join(directory, d) for d in os.listdir(directory)], key=os.path.getmtime)
    # verify query folder starts with query
    assert os.path.basename(queryfolderpath).find("Query_") == -1, "Export Meta data folder not created in " + directory

    # verify Json files and CSV file created
    jsonfiles = [f for f in os.listdir(queryfolderpath) if f.endswith('.json')]
    csvfiles = [f for f in os.listdir(queryfolderpath) if f.endswith('.csv')]

    if len(jsonfiles) != 1:
        filesstring = filesstring + ", Json files count is not equal to 1. created count - " + str(len(jsonfiles))

    if len(csvfiles) != 1:
        filesstring = filesstring + ", csv files count is not equal to 1. created count - " + str(len(csvfiles))

    assert filesstring != "", filesstring[1:]


@step("JSON file data should match the (?P<WSIFilters>.+) filters and (?P<WSIFilterOptions>.+) options")
def step_impl(context, WSIFilters, WSIFilterOptions):
    """
    :type context: behave.runner.Context
    :type WSIFilters: str
    :type WSIFilterOptions: str
    """
    jsonfiles = [f for f in os.listdir(queryfolderpath) if f.endswith('.json')]
    jsonfile = jsonfiles[1]

    # create Json files from the filter and options
    jsonstrfromInput = "{"

    filtersattributes = WSIFilters.split(",")
    filtersoptions = WSIFilterOptions.split("$")

    for ifilter in range(0, len(filtersattributes), 1):
        # get filter options from  filteroptions list
        fileroptions = filtersoptions[ifilter].split("#")
        jsonstrfromInput = jsonstrfromInput + filtersattributes[ifilter] + ":["
        if filtersattributes[ifilter].lower() == "casetag" or filtersattributes[ifilter].lower() == "slidetag":
            valuestr = ""
            for options in fileroptions:
                valuestr = valuestr + "{ \"name\":" + options + "},"

            valuestr = valuestr[0: len(valuestr) - 1]
            jsonstrfromInput = jsonstrfromInput + valuestr + "],"
        elif filtersattributes[ifilter].lower() == "age":
            valuestr = "{ \"ageRangeStart\":" + fileroptions[0] + ", \"ageRangeStart\": " + fileroptions[1] + "}"
            jsonstrfromInput = jsonstrfromInput + valuestr + "],"
        else:
            jsonstrfromInput = jsonstrfromInput + ','.join(fileroptions) + "],"

    if jsonstrfromInput != "":
        jsonstrfromInput = jsonstrfromInput[0: len(jsonstrfromInput) - 1]

    # append by closing the json
    jsonstrfromInput = jsonstrfromInput + "}"

    inputtedjson = json.dumps(jsonstrfromInput, sort_keys=True)
    with open(jsonfile, 'r') as j:
        json_data = json.load(j)
    createdjson = json.dumps(json_data, sort_keys=True)

    assert inputtedjson == createdjson, "Jsons are not matching. System created JSON - " + createdjson + \
                                        ". Inputted filter Json - " + inputtedjson


@step("CSV file data should have (?P<OnlineWSICount>.+) and (?P<ArchiveWSICount>.+) WSI entries")
def step_impl(context, OnlineWSICount, ArchiveWSICount):
    """
    :type context: behave.runner.Context
    :type OnlineWSICount: str
    """

    csvfiles = [f for f in os.listdir(queryfolderpath) if f.endswith('.csv')]
    csvfile = csvfiles[1]
    # read csv files and get count of rows
    with open(csvfile, 'r') as read_obj:
        # pass the file object to reader() to get the reader object
        csv_reader = reader(read_obj)
        list_of_rows = list(csv_reader)

    totalwsi = int(OnlineWSICount) + int(ArchiveWSICount)
    assert len(list_of_rows) - 1 == totalwsi, \
        "In CSV file no of WSI's are not matching. Expected - " + str(totalwsi) + ", Actual - " + str(len(list_of_rows))


@then("OnlineWSICount and OnlineCaseCount should not be Zero")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    global onlinewsicount
    global onlinecasecount
    global archivewsicount
    global archivecasecount

    page = WSISelection(context.driver)
    page.WaitForRunQueryloaded()

    resultsstr = ""
    onlinewsicount = page.GetOnlineWSICount()
    onlinecasecount = page.GetOnlineCasesCount()
    archivewsicount = page.GetArchiveWSICount()
    archivecasecount = page.GetArchiveCasesCount()

    # verify the count
    if onlinewsicount != "--":
        resultsstr = resultsstr + "," + "Online WSI count not matching. Displayed - '--'"

    if onlinecasecount != "--":
        resultsstr = resultsstr + "," + "Online Case count not matching. Displayed - '--'"

    if archivewsicount != "--":
        resultsstr = resultsstr + "," + "Archive WSI count not matching. Displayed - '--'"

    if archivecasecount != "--":
        resultsstr = resultsstr + "," + "Archive Case count not matching. Displayed - '--'"

    assert len(resultsstr) == 0, resultsstr[1:]


@step("Verify number of cases are matching number of folders in output folder")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    # get no of folders from the exportwsi directory
    folders = os.listdir(outputexportedpath)
    assert len(folders) == int(onlinecasecount), "No of case folder is not matching the "


@step("verify CSV file has all column of ExportMetaData")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    errmes = ""
    csvfiles = [f for f in os.listdir(queryfolderpath) if f.endswith('.csv')]
    csvfile = csvfiles[1]
    # get header values
    with open(csvfile, 'r') as read_obj:
        # pass the file object to reader() to get the reader object
        csv_reader = csv.DictReader(read_obj)
        fieldnames = csv_reader.fieldnames

    config_details = cf.get_Config("CaseSelectionUI")
    querycsvcolumns = config_details["querycsvcolumns"]
    li1 = querycsvcolumns.split(",")
    li2 = list(fieldnames)
    finsli = list(set(li1) - set(li2))
    if len(finsli) != 0:
        errmes = errmes + ", Header columns are missing " + ','.join(finsli)

    finsli = list(set(li2) - set(li1))
    if len(finsli) != 0:
        errmes = errmes + ", few Header columns are added " + ','.join(finsli)

    assert errmes == "", errmes[1:]


@step("verify archivestatus of online file is True and archive file is False")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
