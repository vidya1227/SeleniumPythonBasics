from behave import *
import logging
from datetime import datetime

from TestFramework.pages.addfilters import AddFilters
from TestFramework.pages.wsiselection import WSISelection
from TestFramework.pages.calendar import Calendar

use_step_matcher("re")


@given("In the (?P<pagename>.+) page")
def step_impl(context, pagename):
    """
    :type context: behave.runner.Context
    """
    logging.info("In the " + pagename + " page")


@step("Click Add filter link in WSI attribute filters")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    logging.info("Add More link to be clicked")
    page = WSISelection(context.driver)
    page.AddFilters()


@then("Add Filters dialog should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = AddFilters(context.driver)
    visibleval = page.checkAddFilterDialogloaded()
    assert visibleval, 'Add Filters dialog is not displayed'


@then("(?P<MetadataAttribute>.+) filters should be listed in the dialog")
def step_impl(context, MetadataAttribute):
    """
    :type context: behave.runner.Context
    :type MetadataAttribute: str
    """
    page = AddFilters(context.driver)
    filtersattributes = MetadataAttribute.split(",")
    filters = page.verifyWSIsFiltersinAddFilterDialog(filtersattributes)
    assert len(filters) == 0, filters + " WSI filters not listed in Add filters dialog"


@step("Select (?P<MetadataAttribute>.+) WSI attribute filters and click add button")
def step_impl(context, MetadataAttribute):
    """
    :type context: behave.runner.Context
    :type MetadataAttribute: str
    """
    page = AddFilters(context.driver)
    filtersattributes = MetadataAttribute.split(",")
    page.checkWSIsFilters(filtersattributes)
    page.ClickAddinAddFilterdialog()


@then("(?P<MetadataAttribute>.+) filters shall be added to WSI attribute filters in case selection page")
def step_impl(context, MetadataAttribute):
    """
    :type context: behave.runner.Context
    :type MetadataAttribute: str
    """
    page = WSISelection(context.driver)
    filtersattributes = MetadataAttribute.split(",")
    filters = page.VerifyWSIAttributeinCaseSelection(filtersattributes)
    assert len(filters) == 0, filters + " WSI filters not listed in Add filters dialog"


@when("each meta data attribute filter is selected")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    logging.info("Meta data attribute selection started")


@then("(?P<MetadataAttributeOptions>.+) options to be listed for each (?P<MetadataAttribute>.+)")
def step_impl(context, MetadataAttributeOptions, MetadataAttribute):
    """
    :type context: behave.runner.Context
    :type MetadataAttributeOptions: str
    :type MetadataAttribute: str
    """
    filtersattroptions = []
    page = WSISelection(context.driver)
    filtersattributes = MetadataAttribute.split(",")
    filtersoptions = MetadataAttributeOptions.split("$")

    for iopt in range(0, len(filtersattributes), 1):
        filtersattroptions.append(filtersattributes[iopt] + "$" + filtersoptions[iopt])

    filters = page.VerifyMetadataAttributeOptions(filtersattroptions)
    assert len(filters) == 0, filters + " WSI filters options are not matching"


@step("Verify (?P<MetadataAttribute>.+) filters should be selected and disabled")
def step_impl(context, MetadataAttribute):
    """
    :type context: behave.runner.Context
    """

    attributes = ""
    page = AddFilters(context.driver)
    filtersattributes = MetadataAttribute.split(",")
    filterstate = page.getWSIsFiltersstate(filtersattributes)

    filterstates = filterstate.split(",")
    for filter in filterstates:
        if filter.find("enabled") != -1:
            attributes = attributes + "," + filter

    if attributes != "":
        attributes = attributes[1:]

    page.ClickCancelinAddFilterdialog()
    assert len(attributes) == 0, attributes + " metadata attributes are enabled"


@when("for (?P<WSIFilters>.+) select (?P<WSIFilterOptions>.+) and click RunQuery button")
def step_impl(context, WSIFilters, WSIFilterOptions):
    """
    :type context: behave.runner.Context
    :type WSIFilters: str
    :type WSIFilterOptions: str
    """
    filtersattroptions = []
    page = WSISelection(context.driver)
    filtersattributes = WSIFilters.split(",")
    filtersoptions = WSIFilterOptions.split("$")

    for iopt in range(0, len(filtersattributes), 1):
        filtersattroptions.append(filtersattributes[iopt] + "$" + filtersoptions[iopt])

    page.SelectWSIAttribute(filtersattroptions)
    # Click on RunQuery button
    page.ClickRunQueryButton()


@then("(?P<OnlineWSICount>.+) and (?P<OnlineCaseCount>.+) and (?P<ArchiveWSICount>.+) and (?P<ArchiveCaseCount>.+) shown in results")
def step_impl(context, OnlineWSICount, OnlineCaseCount, ArchiveWSICount, ArchiveCaseCount):
    """
    :type context: behave.runner.Context
    :type OnlineWSICount: str
    :type OnlineCaseCount: str
    :type ArchiveWSICount: str
    :type ArchiveCaseCount: str
    """
    page = WSISelection(context.driver)
    page.WaitForRunQueryloaded()

    resultsstr = ""
    onlinewsicount = page.GetOnlineWSICount()
    onlinecasecount = page.GetOnlineCasesCount()
    archivewsicount = page.GetArchiveWSICount()
    archivecasecount = page.GetArchiveCasesCount()

    # verify the count
    if onlinewsicount != OnlineWSICount:
        resultsstr = resultsstr + "," + "Online WSI count not matching. expected - " + OnlineWSICount + ", Actual - " + onlinewsicount

    if onlinecasecount != OnlineCaseCount:
        resultsstr = resultsstr + "," + "Online Case count not matching. expected - " + OnlineCaseCount + ", Actual - " + onlinecasecount

    if archivewsicount != ArchiveWSICount:
        resultsstr = resultsstr + "," + "Archive WSI count not matching. expected - " + ArchiveWSICount + ", Actual - " + archivewsicount

    if archivecasecount != ArchiveCaseCount:
        resultsstr = resultsstr + "," + "Archive Case count not matching. expected - " + ArchiveCaseCount + ", Actual - " + archivecasecount

    assert len(resultsstr) == 0, resultsstr[1:]


@when("ExportWSI's button is clicked")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    page.clickExportWSIButton()


@then("a pop up message should be shown as Export Job has been initiated successfully\.")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    mess = page.verifyExportWSImessage("Export Job has been initiated successfully.")
    page.ClickOKinExportWSIdialog()
    assert mess == True, "Message not matching - Export Job has been initiated successfully."


@step("Click cancel button in Add Filters dialog")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = AddFilters(context.driver)
    page.ClickCancelinAddFilterdialog()


@when("Click cross icon of (?P<UnCheckWSIFilters>.+) WSI attribute")
def step_impl(context, UnCheckWSIFilters):
    """
    :type context: behave.runner.Context
    :type UnCheckWSIFilters: str
    """
    page = WSISelection(context.driver)
    filters = page.RemoveFilterssInCaseSelection(UnCheckWSIFilters)
    assert len(filters) == 0, filters + " not found to remove from the case selection"


@step("Verify (?P<UnCheckWSIFilters>.+) filters should be unselected and enabled")
def step_impl(context, UnCheckWSIFilters):
    """
    :type context: behave.runner.Context
    :type UnCheckWSIFilters: str
    """
    attributes = ""
    page = AddFilters(context.driver)
    filtersattributes = UnCheckWSIFilters.split(",")
    filterstate = page.getWSIsFiltersstate(filtersattributes)

    filterstates = filterstate.split(",")
    for filter in filterstates:
        if filter.find("disable") != -1:
            attributes = attributes + "," + filter

    if attributes != "":
        attributes = attributes[1:]

    page.ClickCancelinAddFilterdialog()
    assert len(attributes) == 0, attributes + " WSI attributes are disabled"


@when("Registration Date text box is clicked")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    page.ClickRegistrationDate()


@then("Registration Date calendar should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Calendar(context.driver)
    visibleval = page.checkRegistrationDateCalendarloaded()
    assert visibleval, 'Registration date calendar is not displayed'


@when("Provide start date (?P<startdate>.+) end date (?P<enddate>.+) and click RunQuery button")
def step_impl(context, startdate, enddate):
    """
    :type context: behave.runner.Context
    :type startdate: str
    :type enddate: str
    """
    calendar = Calendar(context.driver)
    calendar.SelectRegistrationDate(startdate, enddate)
    page = WSISelection(context.driver)
    page.ClickRegistrationDateText()
    page.ClickRunQueryButton()


@step("Create new rule button should not be enabled")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    enableval = page.GetCreateNewRuleEnabled()
    assert enableval == False, 'Create New Rule button is enabled for Registration Date filter'


@step("Today, Clear, Month, Year, Days should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    strNonExists = ""
    page = Calendar(context.driver)
    isToday = page.GetControlDisplayed("registrationdatetoday")
    isClear = page.GetControlDisplayed("registrationdateclear")
    isYear = page.GetControlDisplayed("registrationdateyearcombo")
    isMonth = page.GetControlDisplayed("registrationdatemonthcombo")
    if isToday!= True:
        strNonExists = strNonExists + "," + "Today"
    if isClear != True:
        strNonExists = strNonExists + "," + "Clear"
    if isYear != True:
        strNonExists = strNonExists + "," + "Year"
    if isMonth != True:
        strNonExists = strNonExists + "," + "Month"

    strdays = page.verifydaysstringinCalendar()
    if strdays !="":
        strNonExists = strNonExists + "," + strdays

    assert len(strNonExists) == 0, strNonExists + " control not displayed in registration date calendar"


@step("Todays date should be selected")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Calendar(context.driver)
    strToday = page.GetTodaysSelectedDate()
    currentDay = str(datetime.now().day)
    assert currentDay == strToday, "Selected date is not today. Expected :" + currentDay + ", Actual :" + strToday


@then("pop up should be displayed as Please select/enter filter value\.")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    mess = page.verifyExportWSImessage("Please select/enter filter value.")
    page.ClickOKinExportWSIdialog()
    assert mess == True, "Message not matching - Please select/enter filter value."


@step("Click on the RunQuery button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    # Click on RunQuery button
    page.ClickRunQueryButton()


@when("(?P<pagename>.+) is given as (?P<casedescription>.+)")
def step_impl(context, pagename, casedescription):
    """
    :type context: behave.runner.Context
    :type casedescription: str
    """
    page = WSISelection(context.driver)
    if pagename == "CaseDescription":
        strlist = ["CaseDescription$" + casedescription]
        page.SelectWSIAttribute(strlist)
    elif pagename == "Age":
        strlist = ["Age$" + casedescription]
        page.SelectWSIAttribute(strlist)
    elif pagename == "CaseTag":
        strlist = ["CaseTag$" + casedescription]
        page.SelectWSIAttribute(strlist)
    elif pagename == "StainType":
        strlist = ["StainType$" + casedescription]
        page.SelectWSIAttribute(strlist)
    elif pagename == "CaseState":
        strlist = ["CaseState$" + casedescription]
        page.SelectWSIAttribute(strlist)
    else:
        strlist = ["IssuerStainProtocolIdentifier$" + casedescription]
        page.SelectWSIAttribute(strlist)


@step("Create new rule and Export WSI button should be (?P<state>.+)")
def step_impl(context, state):
    """
    :type context: behave.runner.Context
    :type state: str
    """
    states = ""
    page = WSISelection(context.driver)
    enableval = page.GetCreateNewRuleEnabled()
    if enableval!=bool(state):
        states = states + ", Create New Rule button state is " + state

    enableval = page.GetExportWSIEnabled()
    if enableval != bool(state):
        states = states + ", Export WSI button state is " + state

    assert states == "", "Error - " + states[2:]


