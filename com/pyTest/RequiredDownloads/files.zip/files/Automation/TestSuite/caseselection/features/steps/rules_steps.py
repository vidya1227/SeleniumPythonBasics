from behave import *

from TestFramework.pages.addfilters import AddFilters
from TestFramework.pages.createnewrule import Createnewrule
from TestFramework.pages.deidentifierheader import DeidentifierHeader
from TestFramework.pages.rules import Rules
from TestFramework.pages.wsiselection import WSISelection
from datetime import date, timedelta, datetime

use_step_matcher("re")

ruleappender = datetime.today().strftime('%Y_%m_%d_%H_%M_%S')
thisday = date.today()
startdt = ""
enddt = ""
ruleexetime = ""


@step("Click on the Rules header")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = DeidentifierHeader(context.driver)
    page.ClickRules()


@then("Rules List page should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Rules(context.driver)
    visibleval = page.CheckRulesListloaded()
    assert visibleval, 'Rules List dialog is not opened'


@when("Click on the Create Rule button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Rules(context.driver)
    page.CheckRulesListloaded()
    page.ClickCreateNewRuleButton()


@then("Create Rule page should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Createnewrule(context.driver)
    visibleval = page.CheckCreateRulePageLoaded()
    assert visibleval, 'Create New rule page is not opened'


@when(
    "Rule details like (?P<RuleName>.+), (?P<RuleDescription>.+), (?P<startdate>.+), (?P<enddate>.+), (?P<executiontime>.+), (?P<frequency>.+) provided")
def step_impl(context, RuleName, RuleDescription, startdate, enddate, executiontime, frequency):
    """
    :type context: behave.runner.Context
    :type RuleName: str
    :type RuleDescription: str
    :type startdate: str
    :type enddate: str
    :type executiontime: str
    :type frequency: str
    """
    # global thistime
    page = Createnewrule(context.driver)
    global startdt
    global enddt
    global ruleexetime
    # global ruleappender

    # ruleappender = datetime.today().strftime('%Y_%m_%d_%H_%M_%S')
    today = thisday + timedelta(int(startdate))
    startdt = today.strftime("%Y/%B/%d")
    today = thisday + timedelta(int(enddate))
    enddt = today.strftime("%Y/%B/%d")
    modifiedrulename = RuleName + ruleappender
    ruleexetime = page.ProvideRuleDetails(modifiedrulename, RuleDescription, startdt, enddt, executiontime, frequency)


@when("for (?P<WSIFilters>.+) select (?P<WSIFilterOptions>.+) and Click Save Rule button")
def step_impl(context, WSIFilters, WSIFilterOptions):
    """
    :type context: behave.runner.Context
    :type WSIFilters: str
    :type WSIFilterOptions: str
    """
    filtersattroptions = []
    page = WSISelection(context.driver)
    filtersattributes = WSIFilters.split(",")
    filtersoptions = WSIFilterOptions.split("$")

    for iopt in range(0, len(filtersattributes), 1):
        filtersattroptions.append(filtersattributes[iopt] + "$" + filtersoptions[iopt])

    page.SelectWSIAttribute(filtersattroptions)
    rulepage = Createnewrule(context.driver)
    rulepage.ClickSaveButton()


@then("Rule (?P<RuleName>.+) should be listed in Rule list page")
def step_impl(context, RuleName):
    """
    :type context: behave.runner.Context
    :type RuleName: str
    """
    page = Rules(context.driver)
    visibleval = page.CheckRulesListloaded()
    assert visibleval, 'Rules list page page is not opened'

    modifiedrulename = RuleName + ruleappender
    ruleval = page.VerifyRule(modifiedrulename)
    assert ruleval, RuleName + ' rule not created'


@step(
    "Verify rule details (?P<RuleName>.+) (?P<startdate>.+), (?P<enddate>.+), (?P<executiontime>.+), (?P<frequency>.+)")
def step_impl(context, RuleName, startdate, enddate, executiontime, frequency):
    """
    :type context: behave.runner.Context
    :type RuleName: str
    :type startdate: str
    :type enddate: str
    :type executiontime: str
    :type frequency: str
    """
    message = ""

    page = Rules(context.driver)
    modifiedrulename = RuleName + ruleappender
    ruledetails = page.GetRuleDetails(modifiedrulename)
    assert ruledetails != "", "Details of rules not found for the " + RuleName + " rule"

    # verify the ruledetails
    # today = thisday + timedelta(int(startdate))
    # startdt = today.strftime("%Y/%B/%d")
    # today = thisday + timedelta(int(enddate))
    # enddt = today.strftime("%Y/%B/%d")

    # verify the ruledetails
    ruledets = ruledetails.split("$")
    rulestartdatetime = ruledets[1]
    startdatetime = rulestartdatetime.split(",")
    rulestartdate = datetime.strptime(startdatetime[0], '%d-%b-%Y').strftime('%Y/%B/%d')
    rulestarttime = datetime.strptime(startdatetime[1], ' %I:%M %p').strftime('%H:%M')

    ruleenddatetime = ruledets[2]
    enddatetime = ruleenddatetime.split(",")
    ruleenddate = datetime.strptime(enddatetime[0], '%d-%b-%Y').strftime('%Y/%B/%d')
    ruleendtime = datetime.strptime(enddatetime[1], ' %I:%M %p').strftime('%H:%M')

    rulefrequency = ruledets[3]
    rulelastexecutiondate = ruledets[4]
    rulenextexecutiondate = ruledets[5]

    if startdt != rulestartdate:
        message = message + ", " + "created StartDate - " + startdt + ", " + "rule StartDate - " + str(
            rulestartdate)

    if enddt != ruleenddate:
        message = message + ", " + "created end date - " + enddt + ", " + "rule end date - " + str(
            ruleenddate)

    if ruleexetime != rulestarttime:
        message = message + ", " + "created start time - " + str(executiontime) + ", " + "rule start time - " + str(
            rulestarttime)

    if ruleexetime != ruleendtime:
        message = message + ", " + "created end time - " + str(executiontime) + ", " + "rule end time - " + str(
            ruleendtime)

    if frequency != rulefrequency:
        message = message + ", " + "created frequency - " + str(frequency) + ", " + "rule frequency - " + str(
            rulefrequency)

    if "--" != rulelastexecutiondate:
        message = message + ", " + "rule last executed date - " + str(rulelastexecutiondate)

    if "--" != rulenextexecutiondate:
        message = message + ", " + "rule next executed date - " + str(rulenextexecutiondate)

    assert message == "", "Not matching for " + RuleName + " rule. " + message[2:]


@then("(?P<action>.+) Rule Pop up should be displayed")
def step_impl(context, action):
    """
    :type context: behave.runner.Context
    """
    page = Rules(context.driver)
    message = ""
    if action == "Create":
        message = "Rule created successfully."
    else:
        message = "Rule deleted successfully."

    dialogval = page.VerifyRulePopup(message)
    assert dialogval, "Create rule popup message is not matching - " + message
    page.ClickOKButtonInDialog()


@then("Rule already exists pop up should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Rules(context.driver)  ## Steps shuld be changed
    dialogval = page.VerifyRulePopup("Rule name already exists.")
    assert dialogval, "Create rule popup message is not matching - ' Rule name already exists. '"
    page.ClickOKButtonInDialog()


@when("Select the (?P<RuleName>.+) and click delete button")
def step_impl(context, RuleName):
    """
    :type context: behave.runner.Context
    :type RuleName: str
    """
    page = Rules(context.driver)
    modifiedrulename = RuleName + ruleappender
    dialogval = page.DeleteRule(modifiedrulename)
    assert dialogval, "Delete rule popup message is not matching - 'Are you sure, you want to delete the Rule ?'"
    page.ClickYesButtonInDeleteDialog()


@step("Rule (?P<RuleName>.+) should not be listed in Rule list page")
def step_impl(context, RuleName):
    """
    :type context: behave.runner.Context
    :type RuleName: str
    """
    page = Rules(context.driver)
    visibleval = page.CheckRulesListloaded()
    assert visibleval, 'Rule list page is not opened'

    ruleval = page.VerifyRule(RuleName)
    assert ruleval == False, RuleName + ' rule is still shown in the list'


@step("Click on Save Rule button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Createnewrule(context.driver)
    page.ClickSaveButton()


@then("A pop up should be shown as (?P<message>.+)")
def step_impl(context, message):
    """
    :type context: behave.runner.Context
    """
    page = Rules(context.driver)
    dialogval = page.VerifyRulePopup(message)
    assert dialogval, "Create rule popup message is not matching - " + message
    page.ClickOKButtonInDialog()


@when("(?P<fieldName>.+) is provided as (?P<Filter>.+) and Click on Save Rule button")
def step_impl(context, fieldName, Filter):
    """
    :type context: behave.runner.Context
    :type Filter: str
    """
    page = Createnewrule(context.driver)
    if fieldName == "Filter":
        wsipage = WSISelection(context.driver)
        wsipage.AddFilters()
        addpage = AddFilters(context.driver)
        addpage.checkAddFilterDialogloaded()
        filtersattributes = Filter.split(",")
        addpage.checkWSIsFilters(filtersattributes)
        addpage.ClickAddinAddFilterdialog()
        filtersattroptions = ["CaseDescription$FromScripts"]
        wsipage = WSISelection(context.driver)
        wsipage.SelectWSIAttribute(filtersattroptions)
    elif fieldName == "RuleName":
        page.EnterRuleName(Filter)
    elif fieldName == "RuleDescription":
        page.EnterRuleDescription(Filter)
    elif fieldName == "Startdate":
        today = date.today() + timedelta(int(Filter))
        StartDate = today.strftime("%Y/%B/%d")
        page.EnterStartDate(StartDate)
    elif fieldName == "Enddate":
        today = date.today() + timedelta(int(Filter))
        EndDate = today.strftime("%Y/%B/%d")
        page.EnterEndDate(EndDate)
    elif fieldName == "Executiontime":
        page.EnterExecutionTime(Filter)

    page.ClickSaveButton()


@when("Frequency is provided as 2 and Click on Cancel button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = Createnewrule(context.driver)
    page.EnterFrequency("2")
    page.ClickCancelButton()


@then("Click on Create New Rule button")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    page.WaitForRunQueryloaded()
    page.ClickCreateNewRuleButton()


@step("(?P<WSIFilters>.+) options to be selected as (?P<WSIFilterOptions>.+)")
def step_impl(context, WSIFilters, WSIFilterOptions):
    """
    :type context: behave.runner.Context
    :type WSIFilters: str
    :type WSIFilterOptions: str
    """
    filtersattroptions = []
    page = WSISelection(context.driver)
    filtersattributes = WSIFilters.split(",")
    filtersoptions = WSIFilterOptions.split("$")

    for iopt in range(0, len(filtersattributes), 1):
        filtersattroptions.append(filtersattributes[iopt] + "$" + filtersoptions[iopt])

    filters = page.VerifyMetadataAttributeValues(filtersattroptions)
    assert len(filters) == 0, filters + " WSI filters options are not matching"


@step(
    "For the (?P<RoleName>.+) role, (?P<RuleName>.+) rule (?P<RuleshowforRole>.+) be listed when created using different role")
def step_impl(context, RoleName, RuleName, RuleshowforRole):
    """
    :type context: behave.runner.Context
    :type RoleName: str
    :type RuleName: str
    :type RuleshowforRole: str
    """
    page = Rules(context.driver)
    visibleval = page.CheckRulesListloaded()
    assert visibleval, 'Rules list page is not opened'

    modifiedrulename = RuleName + ruleappender
    ruleval = page.VerifyRule(modifiedrulename)

    ruletodisplay = False
    errmess = modifiedrulename + " Rule should be listed for " + RoleName
    if RuleshowforRole == "should":
        ruletodisplay = True
        errmess = modifiedrulename + " Rule not listed for " + RoleName

    assert ruleval == ruletodisplay, errmess


@when("(?P<RoleName>.+) is deleting the rule (?P<RuleName>.+)")
def step_impl(context, RoleName, RuleName):
    """
    :type context: behave.runner.Context
    :type RoleName: str
    :type RuleName: str
    """
    page = Rules(context.driver)
    modifiedrulename = RuleName + ruleappender
    ruleval = page.VerifyRule(modifiedrulename)

    if RoleName == "Administrator":
        assert ruleval == False, "Data Manager has permission to delete the rule created by Administrator"
    else:
        assert ruleval, "Administrator do not have permission to delete the rule created by Datamanager"


@then("For the (?P<RoleName>.+) role, (?P<RuleName>.+) Rule (?P<Deleterule>.+) be allowed to delete")
def step_impl(context, RoleName, RuleName, Deleterule):
    """
    :type context: behave.runner.Context
    :type RoleName: str
    :type RuleName: str
    :type Deleterule: str
    """
    if RoleName == "Administrator":
        # In the previous steps, it is verified that datamanager is not able to see rule created by Admin, hence writing as Pass
        assert True, "Data Manager have permission to delete the rule created by Administrator"
    else:
        page = Rules(context.driver)
        modifiedrulename = RuleName + ruleappender
        dialogval = page.DeleteRule(modifiedrulename)
        assert dialogval, "Delete rule popup message is not matching - 'Are you sure, you want to delete the Rule ?'"
        page.ClickYesButtonInDeleteDialog()
        page.ClickOKButtonInDialog()


@step("Click Cancel button in create new rule page")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    rulepage = Createnewrule(context.driver)
    rulepage.ClickCancelButton()