from behave import *
from TestFramework.pages.caseselection_login import CaseSelection_Login
from TestFramework.pages.deidentifierheader import DeidentifierHeader
from TestFramework.pages.wsiselection import WSISelection
import TestFramework.utility.config as cf

use_step_matcher("re")


@given("Login page of case selection application")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    config_details = cf.get_Config("CaseSelectionUI")
    context.driver.get(config_details["url"])


@when("(?P<username>.+) and (?P<password>.+) are provided and LogIn button is clicked")
def step_impl(context, username, password):
    """
    :type context: behave.runner.Context
    :type username: str
    :type password: str
    """
    page = CaseSelection_Login(context.driver)
    # wait till page loads
    page.checkcaseselectionloginpageloaded()
    config_details = cf.get_Config("CaseSelectionUI")
    # get username and password from the config file if the values are empty
    if username == "config" or password == "config":
        username = config_details["username"]
        password = config_details["password"]
    elif username == "datamanager" or password == "datamanager":
        username = config_details["datamanagerusername"]
        password = config_details["datamanagerpassword"]

    page.login(username, password)


@then("case selection page should be displayed")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = WSISelection(context.driver)
    visibleval = page.checkWSISelectionpageloaded()
    assert visibleval, 'WSI Selection page is not displayed'


@when("to test with (?P<username>.+) and (?P<password>.+)")
def step_impl(context, username, password):
    """
    :type context: behave.runner.Context
    :type username: str
    :type password: str
    """
    print("STEP: When to test with " + username +" and " + password)


@then("it should able to write text from the pritn")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    print("In the step 1")


@given("to run the steps for multiple times")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    print("STEP: Given to run the steps for multiple times")


@when("we run the (?P<stepnumber>.+) in for multiple times")
def step_impl(context, stepnumber):
    """
    :type context: behave.runner.Context
    :type stepnumber: str
    """
    print("STEP: When we run the " + stepnumber + " in for multiple times")


@then("it should write log")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    print("STEP: Then it should write log")


@given("wahhhs is the tet")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    print("Start of the scenario")


@step("Logoff from the application")
def step_impl(context):
    """
    :type context: behave.runner.Context
    """
    page = DeidentifierHeader(context.driver)
    page.LogoutDeid()