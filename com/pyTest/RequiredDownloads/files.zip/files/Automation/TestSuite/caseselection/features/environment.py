from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from datetime import date, timedelta, datetime

ruleappender=""


def before_all(context):
    print("Starting the Execution")


def before_feature(context, feature):
    print("In the feature execution")


def before_scenario(context, scenario):
    options = webdriver.ChromeOptions()
    options.add_argument("start-maximized")
    options.add_argument('--ignore-certificate-errors')

    # context.driver  = webdriver.Chrome(chrome_options=options, executable_path=ChromeDriverManager().install())
    context.driver = webdriver.Chrome(chrome_options=options, executable_path="C:\chromedriver.exe")
    #context.driver = webdriver.Chrome("C:\chromedriver.exe")
    print("In the scenario Execution - ")




def after_scenario(context, scenario):
    print("In the after scenario Execution - ")
    context.driver.quit()


def after_feature(context, feature):
    print("In the feature exit - ")


def after_all(context):
    print("Execution completed")
